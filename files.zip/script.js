// หา element 3 ตัวที่ต้องใช้: ปุ่มสวิตช์, ตัวบอกสถานะ, และ <html> เพื่อสลับ data-power
const powerSwitch = document.getElementById('powerSwitch');
const powerState  = document.getElementById('powerState');
const root        = document.documentElement; // คือ <html>

powerSwitch.addEventListener('click', () => {
  // เช็คสถานะปัจจุบันจาก attribute บน <html>
  const isOn = root.getAttribute('data-power') === 'on';

  // สลับค่า: ถ้าเปิดอยู่ -> ปิด, ถ้าปิดอยู่ -> เปิด
  const next = isOn ? 'off' : 'on';
  root.setAttribute('data-power', next);

  // อัปเดตข้อความและ accessibility state ให้ตรงกับสถานะใหม่
  powerState.textContent = next.toUpperCase();
  powerSwitch.setAttribute('aria-pressed', String(next === 'on'));
});
